#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import sys
import xbmcgui
import xbmcplugin
import xbmcaddon
from urllib.parse import urlencode, parse_qsl
import json
import requests
import re

# Addon info
addon = xbmcaddon.Addon()
addon_id = addon.getAddonInfo('id')
addon_name = addon.getAddonInfo('name')
addon_icon = addon.getAddonInfo('icon')
addon_fanart = addon.getAddonInfo('fanart')

# Plugin handle
handle = int(sys.argv[1])

# Repositório de ícones alternativos
LOGO_BASE_URL = "https://iptv-org.github.io/api/logos/"

# Canais Originais (Embed TV Online)
CHANNELS_ORIGINAL = [
    {"name": "Amazon Prime Video", "category": "Esportes", "url": "https://embedtvonline.com/amazonprimevideo/"},
    {"name": "Band Sports", "category": "Esportes", "url": "https://embedtvonline.com/bandsports/"},
    {"name": "Canal Off", "category": "Esportes", "url": "https://embedtvonline.com/canaloff/"},
    {"name": "CazéTV", "category": "Esportes", "url": "https://embedtvonline.com/cazetv/"},
    {"name": "Combate", "category": "Esportes", "url": "https://embedtvonline.com/combate/"},
    {"name": "DAZN", "category": "Esportes", "url": "https://embedtvonline.com/dazn/"},
    {"name": "Disney+", "category": "Esportes", "url": "https://embedtvonline.com/disneyplus/"},
    {"name": "ESPN", "category": "Esportes", "url": "https://embedtvonline.com/espn/"},
    {"name": "ESPN 2", "category": "Esportes", "url": "https://embedtvonline.com/espn2/"},
    {"name": "ESPN 3", "category": "Esportes", "url": "https://embedtvonline.com/espn3/"},
    {"name": "ESPN 4", "category": "Esportes", "url": "https://embedtvonline.com/espn4/"},
    {"name": "ESPN 5", "category": "Esportes", "url": "https://embedtvonline.com/espn5/"},
    {"name": "ESPN 6", "category": "Esportes", "url": "https://embedtvonline.com/espn6/"},
    {"name": "Max", "category": "Esportes", "url": "https://embedtvonline.com/max/"},
    {"name": "Nosso Futebol", "category": "Esportes", "url": "https://embedtvonline.com/nossofutebol/"},
    {"name": "N Sports", "category": "Esportes", "url": "https://embedtvonline.com/nsports/"},
    {"name": "Paramount +", "category": "Esportes", "url": "https://embedtvonline.com/paramountplus/"},
    {"name": "Premiere Clubes", "category": "Esportes", "url": "https://embedtvonline.com/premiereclubes/"},
    {"name": "Premiere 2", "category": "Esportes", "url": "https://embedtvonline.com/premiere2/"},
    {"name": "Premiere 3", "category": "Esportes", "url": "https://embedtvonline.com/premiere3/"},
    {"name": "Premiere 4", "category": "Esportes", "url": "https://embedtvonline.com/premiere4/"},
    {"name": "Premiere 5", "category": "Esportes", "url": "https://embedtvonline.com/premiere5/"},
    {"name": "Premiere 6", "category": "Esportes", "url": "https://embedtvonline.com/premiere6/"},
    {"name": "Premiere 7", "category": "Esportes", "url": "https://embedtvonline.com/premiere7/"},
    {"name": "Premiere 8", "category": "Esportes", "url": "https://embedtvonline.com/premiere8/"},
    {"name": "SporTV", "category": "Esportes", "url": "https://embedtvonline.com/sportv/"},
    {"name": "SporTV 2", "category": "Esportes", "url": "https://embedtvonline.com/sportv2/"},
    {"name": "SporTV 3", "category": "Esportes", "url": "https://embedtvonline.com/sportv3/"},
    {"name": "TNT", "category": "Esportes", "url": "https://embedtvonline.com/tnt/"},
    {"name": "UFC Fight Pass", "category": "Esportes", "url": "https://embedtvonline.com/ufcfightpass/"},
    {"name": "Xsports", "category": "Esportes", "url": "https://embedtvonline.com/xsports/"},
    {"name": "A&E", "category": "Filmes e Séries", "url": "https://embedtvonline.com/aee/"},
    {"name": "AMC", "category": "Filmes e Séries", "url": "https://embedtvonline.com/amc/"},
    {"name": "AXN", "category": "Filmes e Séries", "url": "https://embedtvonline.com/axn/"},
    {"name": "Cinemax", "category": "Filmes e Séries", "url": "https://embedtvonline.com/cinemax/"},
    {"name": "Globoplay Novelas", "category": "Filmes e Séries", "url": "https://embedtvonline.com/globoplaynovelas/"},
    {"name": "HBO", "category": "Filmes e Séries", "url": "https://embedtvonline.com/hbo/"},
    {"name": "HBO 2", "category": "Filmes e Séries", "url": "https://embedtvonline.com/hbo2/"},
    {"name": "HBO Family", "category": "Filmes e Séries", "url": "https://embedtvonline.com/hbofamily/"},
    {"name": "HBO Mundi", "category": "Filmes e Séries", "url": "https://embedtvonline.com/hbomundi/"},
    {"name": "HBO Plus", "category": "Filmes e Séries", "url": "https://embedtvonline.com/hboplus/"},
    {"name": "HBO Pop", "category": "Filmes e Séries", "url": "https://embedtvonline.com/hbopop/"},
    {"name": "HBO Signature", "category": "Filmes e Séries", "url": "https://embedtvonline.com/hbosignature/"},
    {"name": "HBO Xtreme", "category": "Filmes e Séries", "url": "https://embedtvonline.com/hboxtreme/"},
    {"name": "Megapix", "category": "Filmes e Séries", "url": "https://embedtvonline.com/megapix/"},
    {"name": "Paramount Network", "category": "Filmes e Séries", "url": "https://embedtvonline.com/paramountnetwork/"},
    {"name": "Sony Channel", "category": "Filmes e Séries", "url": "https://embedtvonline.com/sonychannel/"},
    {"name": "Space", "category": "Filmes e Séries", "url": "https://embedtvonline.com/space/"},
    {"name": "Studio Universal", "category": "Filmes e Séries", "url": "https://embedtvonline.com/studiouniversal/"},
    {"name": "Telecine Action", "category": "Filmes e Séries", "url": "https://embedtvonline.com/tcaction/"},
    {"name": "Telecine Cult", "category": "Filmes e Séries", "url": "https://embedtvonline.com/tccult/"},
    {"name": "Telecine Fun", "category": "Filmes e Séries", "url": "https://embedtvonline.com/tcfun/"},
    {"name": "Telecine Pipoca", "category": "Filmes e Séries", "url": "https://embedtvonline.com/tcpipoca/"},
    {"name": "Telecine Premium", "category": "Filmes e Séries", "url": "https://embedtvonline.com/tcpremium/"},
    {"name": "Telecine Touch", "category": "Filmes e Séries", "url": "https://embedtvonline.com/tctouch/"},
    {"name": "TNT Novelas", "category": "Filmes e Séries", "url": "https://embedtvonline.com/tntnovelas/"},
    {"name": "TNT Series", "category": "Filmes e Séries", "url": "https://embedtvonline.com/tntseries/"},
    {"name": "Universal TV", "category": "Filmes e Séries", "url": "https://embedtvonline.com/universaltv/"},
    {"name": "Warner Channel", "category": "Filmes e Séries", "url": "https://embedtvonline.com/warner/"},
    {"name": "Band SP", "category": "Canais Abertos", "url": "https://embedtvonline.com/bandsp/"},
    {"name": "Globo MG", "category": "Canais Abertos", "url": "https://embedtvonline.com/globomg/"},
    {"name": "Globo RJ", "category": "Canais Abertos", "url": "https://embedtvonline.com/globorj/"},
    {"name": "Globo RS", "category": "Canais Abertos", "url": "https://embedtvonline.com/globors/"},
    {"name": "Globo SP", "category": "Canais Abertos", "url": "https://embedtvonline.com/globosp/"},
    {"name": "Record MG", "category": "Canais Abertos", "url": "https://embedtvonline.com/recordmg/"},
    {"name": "Record RJ", "category": "Canais Abertos", "url": "https://embedtvonline.com/recordrj/"},
    {"name": "Record SP", "category": "Canais Abertos", "url": "https://embedtvonline.com/recordsp/"},
    {"name": "RedeTV!", "category": "Canais Abertos", "url": "https://embedtvonline.com/redetv/"},
    {"name": "SBT SP", "category": "Canais Abertos", "url": "https://embedtvonline.com/sbtsp/"},
    {"name": "TV Cultura", "category": "Canais Abertos", "url": "https://embedtvonline.com/tvcultura/"},
    {"name": "Adult Swim", "category": "Variedades", "url": "https://embedtvonline.com/adultswim/"},
    {"name": "Animal Planet", "category": "Variedades", "url": "https://embedtvonline.com/animalplanet/"},
    {"name": "Comedy Central", "category": "Variedades", "url": "https://embedtvonline.com/comedycentral/"},
    {"name": "Discovery Channel", "category": "Variedades", "url": "https://embedtvonline.com/discoverychannel/"},
    {"name": "Discovery Home & Health", "category": "Variedades", "url": "https://embedtvonline.com/discoveryhh/"},
    {"name": "Investigation Discovery", "category": "Variedades", "url": "https://embedtvonline.com/discoveryid/"},
    {"name": "Discovery Science", "category": "Variedades", "url": "https://embedtvonline.com/discoveryscience/"},
    {"name": "Discovery Theater", "category": "Variedades", "url": "https://embedtvonline.com/discoverytheater/"},
    {"name": "Discovery Turbo", "category": "Variedades", "url": "https://embedtvonline.com/discoveryturbo/"},
    {"name": "Discovery World", "category": "Variedades", "url": "https://embedtvonline.com/discoveryworld/"},
    {"name": "Food Network", "category": "Variedades", "url": "https://embedtvonline.com/foodnetwork/"},
    {"name": "GNT", "category": "Variedades", "url": "https://embedtvonline.com/gnt/"},
    {"name": "HGTV", "category": "Variedades", "url": "https://embedtvonline.com/hgtv/"},
    {"name": "History", "category": "Variedades", "url": "https://embedtvonline.com/history/"},
    {"name": "History 2", "category": "Variedades", "url": "https://embedtvonline.com/history2/"},
    {"name": "MTV", "category": "Variedades", "url": "https://embedtvonline.com/mtv/"},
    {"name": "Multishow", "category": "Variedades", "url": "https://embedtvonline.com/multishow/"},
    {"name": "BandNews", "category": "Notícias", "url": "https://embedtvonline.com/bandnews/"},
    {"name": "CNN Brasil", "category": "Notícias", "url": "https://embedtvonline.com/cnnbrasil/"},
    {"name": "GloboNews", "category": "Notícias", "url": "https://embedtvonline.com/globonews/"},
    {"name": "Jovem Pan News", "category": "Notícias", "url": "https://embedtvonline.com/jovempannews/"},
    {"name": "Record News", "category": "Notícias", "url": "https://embedtvonline.com/recordnews/"},
    {"name": "Cartoonito", "category": "Infantil", "url": "https://embedtvonline.com/cartoonito/"},
    {"name": "Cartoon Network", "category": "Infantil", "url": "https://embedtvonline.com/cartoonnetwork/"},
    {"name": "Discovery Kids", "category": "Infantil", "url": "https://embedtvonline.com/discoverykids/"},
    {"name": "DreamWorks", "category": "Infantil", "url": "https://embedtvonline.com/dreamworks/"},
    {"name": "Gloob", "category": "Infantil", "url": "https://embedtvonline.com/gloob/"},
    {"name": "Gloobinho", "category": "Infantil", "url": "https://embedtvonline.com/gloobinho/"},
    {"name": "Nickelodeon", "category": "Infantil", "url": "https://embedtvonline.com/nickelodeon/"},
    {"name": "Nick Jr.", "category": "Infantil", "url": "https://embedtvonline.com/nickjr/"},
    {"name": "Tooncast", "category": "Infantil", "url": "https://embedtvonline.com/tooncast/"},
]

# Estrutura de Categorias M3U conforme solicitado
M3U_CATEGORIES = [
    {"name": "🇧🇷 Brazil", "urls": ["https://iptv-org.github.io/iptv/countries/br.m3u"]},
    {"name": "Alagoas", "urls": [
        "https://iptv-org.github.io/iptv/subdivisions/br-al.m3u",
        "https://iptv-org.github.io/iptv/cities/brmcz.m3u"
    ]},
    {"name": "Amazonas", "urls": ["https://iptv-org.github.io/iptv/subdivisions/br-am.m3u"]},
    {"name": "Bahia", "urls": ["https://iptv-org.github.io/iptv/subdivisions/br-ba.m3u"]},
    {"name": "Ceara", "urls": ["https://iptv-org.github.io/iptv/subdivisions/br-ce.m3u"]},
    {"name": "Distrito Federal", "urls": [
        "https://iptv-org.github.io/iptv/subdivisions/br-df.m3u",
        "https://iptv-org.github.io/iptv/cities/brbsb.m3u"
    ]},
    {"name": "Espirito Santo", "urls": [
        "https://iptv-org.github.io/iptv/subdivisions/br-es.m3u",
        "https://iptv-org.github.io/iptv/cities/brcdi.m3u",
        "https://iptv-org.github.io/iptv/cities/brctn.m3u",
        "https://iptv-org.github.io/iptv/cities/brsms.m3u"
    ]},
    {"name": "Goias", "urls": [
        "https://iptv-org.github.io/iptv/subdivisions/br-go.m3u",
        "https://iptv-org.github.io/iptv/cities/brclv.m3u"
    ]},
    {"name": "Maranhao", "urls": [
        "https://iptv-org.github.io/iptv/subdivisions/br-ma.m3u",
        "https://iptv-org.github.io/iptv/cities/brcxs.m3u"
    ]},
    {"name": "Mato Grosso", "urls": [
        "https://iptv-org.github.io/iptv/subdivisions/br-mt.m3u",
        "https://iptv-org.github.io/iptv/cities/brcba.m3u",
        "https://iptv-org.github.io/iptv/cities/brtse.m3u"
    ]},
    {"name": "Minas Gerais", "urls": [
        "https://iptv-org.github.io/iptv/subdivisions/br-mg.m3u",
        "https://iptv-org.github.io/iptv/cities/brpoo.m3u",
        "https://iptv-org.github.io/iptv/cities/brssp.m3u",
        "https://iptv-org.github.io/iptv/cities/brudi.m3u",
        "https://iptv-org.github.io/iptv/cities/brvis.m3u"
    ]},
    {"name": "Para", "urls": [
        "https://iptv-org.github.io/iptv/subdivisions/br-pa.m3u",
        "https://iptv-org.github.io/iptv/cities/brcas.m3u"
    ]},
    {"name": "Paraiba", "urls": [
        "https://iptv-org.github.io/iptv/subdivisions/br-pb.m3u",
        "https://iptv-org.github.io/iptv/cities/brjpa.m3u"
    ]},
    {"name": "Parana", "urls": [
        "https://iptv-org.github.io/iptv/subdivisions/br-pr.m3u",
        "https://iptv-org.github.io/iptv/cities/brcwb.m3u"
    ]},
    {"name": "Pernambuco", "urls": [
        "https://iptv-org.github.io/iptv/subdivisions/br-pe.m3u",
        "https://iptv-org.github.io/iptv/cities/brsrb.m3u"
    ]},
    {"name": "Rio de Janeiro", "urls": [
        "https://iptv-org.github.io/iptv/subdivisions/br-rj.m3u",
        "https://iptv-org.github.io/iptv/cities/brcfo.m3u",
        "https://iptv-org.github.io/iptv/cities/brmrc.m3u",
        "https://iptv-org.github.io/iptv/cities/brnfu.m3u"
    ]},
    {"name": "Rio Grande do Norte", "urls": [
        "https://iptv-org.github.io/iptv/subdivisions/br-rn.m3u",
        "https://iptv-org.github.io/iptv/cities/brnat.m3u"
    ]},
    {"name": "Rio Grande do Sul", "urls": [
        "https://iptv-org.github.io/iptv/subdivisions/br-rs.m3u",
        "https://iptv-org.github.io/iptv/cities/brpfo.m3u",
        "https://iptv-org.github.io/iptv/cities/brpoa.m3u"
    ]},
    {"name": "Rondonia", "urls": ["https://iptv-org.github.io/iptv/subdivisions/br-ro.m3u"]},
    {"name": "Santa Catarina", "urls": [
        "https://iptv-org.github.io/iptv/subdivisions/br-sc.m3u",
        "https://iptv-org.github.io/iptv/cities/brbac.m3u",
        "https://iptv-org.github.io/iptv/cities/brjoi.m3u",
        "https://iptv-org.github.io/iptv/cities/brsje.m3u"
    ]},
    {"name": "Sao Paulo", "urls": [
        "https://iptv-org.github.io/iptv/subdivisions/br-sp.m3u",
        "https://iptv-org.github.io/iptv/cities/braru.m3u",
        "https://iptv-org.github.io/iptv/cities/brgus.m3u",
        "https://iptv-org.github.io/iptv/cities/briig.m3u",
        "https://iptv-org.github.io/iptv/cities/brjun.m3u",
        "https://iptv-org.github.io/iptv/cities/brssz.m3u",
        "https://iptv-org.github.io/iptv/cities/brsao.m3u",
        "https://iptv-org.github.io/iptv/cities/brszo.m3u"
    ]},
    {"name": "Canais de Música", "urls": ["https://iptv-org.github.io/iptv/categories/music.m3u"]},
    {"name": "Canais de Língua Portuguesa", "urls": ["https://iptv-org.github.io/iptv/languages/por.m3u"]},
    {"name": "Canais de Língua Espanhola", "urls": ["https://iptv-org.github.io/iptv/languages/spa.m3u"]}
]

def get_logo(name):
    """Busca logo alternativo"""
    clean = re.sub(r'[^a-zA-Z0-9]', '', name).lower()
    return f"{LOGO_BASE_URL}{clean}.png"

def list_main_menu():
    """Menu Principal"""
    # Categorias Originais
    orig_cats = sorted(list(set(ch['category'] for ch in CHANNELS_ORIGINAL)))
    for cat in orig_cats:
        url = f"{sys.argv[0]}?action=list_original&category={cat}"
        list_item = xbmcgui.ListItem(label=f"[COLOR yellow][B]{cat}[/B][/COLOR]")
        list_item.setArt({'icon': addon_icon, 'fanart': addon_fanart})
        xbmcplugin.addDirectoryItem(handle=handle, url=url, listitem=list_item, isFolder=True)

    # Categorias M3U (Brasil e Estados)
    for item in M3U_CATEGORIES:
        url = f"{sys.argv[0]}?action=list_m3u_channels&category_index={M3U_CATEGORIES.index(item)}"
        list_item = xbmcgui.ListItem(label=item['name'])
        list_item.setArt({'icon': addon_icon, 'fanart': addon_fanart})
        xbmcplugin.addDirectoryItem(handle=handle, url=url, listitem=list_item, isFolder=True)
    
    xbmcplugin.endOfDirectory(handle)

def list_original(category):
    """Lista canais da Embed TV"""
    channels = [ch for ch in CHANNELS_ORIGINAL if ch['category'] == category]
    for ch in channels:
        url = f"{sys.argv[0]}?action=play_original&url={ch['url']}"
        list_item = xbmcgui.ListItem(label=ch['name'])
        list_item.setArt({'icon': get_logo(ch['name']), 'fanart': addon_fanart})
        list_item.setProperty('IsPlayable', 'true')
        xbmcplugin.addDirectoryItem(handle=handle, url=url, listitem=list_item)
    xbmcplugin.endOfDirectory(handle)

def list_m3u_channels(category_index):
    """Lista canais de uma categoria M3U (pode conter várias URLs)"""
    category = M3U_CATEGORIES[int(category_index)]
    for m3u_url in category['urls']:
        try:
            r = requests.get(m3u_url, timeout=10)
            if r.status_code == 200:
                # Captura logo, nome e stream
                items = re.findall(r'#EXTINF:.*?(?:tvg-logo="(.*?)")?.*?,(.*?)\n(https?://.*)', r.text)
                for logo, name, stream in items:
                    name = name.strip()
                    logo = logo.strip() if logo else get_logo(name)
                    url = f"{sys.argv[0]}?action=play_direct&url={stream.strip()}"
                    list_item = xbmcgui.ListItem(label=name)
                    list_item.setArt({'icon': logo, 'fanart': addon_fanart})
                    list_item.setProperty('IsPlayable', 'true')
                    xbmcplugin.addDirectoryItem(handle=handle, url=url, listitem=list_item)
        except: continue
    xbmcplugin.endOfDirectory(handle)

def extract_m3u8(page_url):
    """Extrai link m3u8 de página HTML"""
    headers = {'User-Agent': 'Mozilla/5.0', 'Referer': 'https://embedtvonline.com/'}
    try:
        r = requests.get(page_url, headers=headers, timeout=10)
        match = re.search(r'["\'](https?://[^"\']+\.m3u8[^"\']*)["\']', r.text)
        return match.group(1) if match else None
    except: return None

def play_original(url):
    video_url = extract_m3u8(url)
    if video_url:
        final = f"{video_url}|Referer=https://embedtvonline.com/&User-Agent=Mozilla/5.0"
        xbmcplugin.setResolvedUrl(handle, True, xbmcgui.ListItem(path=final))
    else:
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())

def play_direct(url):
    xbmcplugin.setResolvedUrl(handle, True, xbmcgui.ListItem(path=url))

def router(paramstring):
    params = dict(parse_qsl(paramstring))
    if not params: list_main_menu()
    else:
        action = params.get('action')
        if action == 'list_original': list_original(params.get('category'))
        elif action == 'list_m3u_channels': list_m3u_channels(params.get('category_index'))
        elif action == 'play_original': play_original(params.get('url'))
        elif action == 'play_direct': play_direct(params.get('url'))

if __name__ == '__main__':
    router(sys.argv[2][1:])
