# Changelog - TV DO BILL

## [1.0.0] - 2026-01-07

### Adicionado
- Versão inicial do addon
- 101 canais de TV ao vivo
- 6 categorias de conteúdo:
  - Esportes (31 canais)
  - Filmes e Séries (28 canais)
  - Canais Abertos (11 canais)
  - Variedades (17 canais)
  - Notícias (5 canais)
  - Infantil (9 canais)
- Interface simples e intuitiva
- Compatibilidade com Kodi 21+ (Omega)
- Logo e fanart personalizados
- Suporte a português brasileiro

### Características
- Agregador de links do Embed TV Online
- Sem anúncios
- Navegação por categoria
- Reprodução direta de streams
- Otimizado para Smart TVs

---

## Futuras Versões

### Planejado para v1.1.0
- Busca de canais
- Favoritos/Watchlist
- Histórico de visualização
- Suporte a legendas
- Melhorias de performance

### Planejado para v1.2.0
- Atualização automática de canais
- Suporte a múltiplos idiomas
- Integração com EPG (Guia de Programação)
- Notificações de novos canais
