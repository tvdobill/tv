# TV DO BILL - Addon Kodi

Um addon para Kodi 21+ que agrega canais de TV ao vivo do **Embed TV Online**.

## 📺 Características

- **101 canais de TV ao vivo** organizados em 7 categorias
- **Interface simples** e otimizada para Smart TVs
- **Sem anúncios** - Apenas links de conteúdo
- **Compatível com Kodi 21+** (Omega e superiores)
- **Suporte a múltiplas categorias**:
  - Esportes (31 canais)
  - Filmes e Séries (28 canais)
  - Canais Abertos (11 canais)
  - Variedades (17 canais)
  - Notícias (5 canais)
  - Infantil (9 canais)

## 🚀 Instalação

### Método 1: Instalação Manual

1. Baixe o arquivo `plugin.video.tvdobill.zip`
2. No Kodi, vá para **Configurações > Gerenciador de Arquivos**
3. Adicione uma fonte apontando para a pasta onde o arquivo está
4. Vá para **Add-ons > Instalar a partir de um arquivo ZIP**
5. Selecione o arquivo `plugin.video.tvdobill.zip`
6. Aguarde a instalação

### Método 2: Instalação Manual (Pasta)

1. Extraia a pasta `plugin.video.tvdobill`
2. Copie para: `~/.kodi/addons/` (Linux/Mac) ou `%APPDATA%\kodi\addons\` (Windows)
3. Reinicie o Kodi

## 📋 Requisitos

- **Kodi 21.0+** (Omega ou superior)
- Conexão com a internet
- Navegador de vídeo compatível (recomendado: InputStream Adaptive)

## 🎮 Como Usar

1. Abra o Kodi
2. Vá para **Add-ons > Vídeos > TV DO BILL**
3. Selecione uma categoria
4. Escolha um canal
5. Clique para reproduzir

## ⚙️ Configuração

O addon não requer configuração adicional. Todos os canais estão pré-configurados.

## 🔗 Fonte de Conteúdo

Os canais são agregados do site [Embed TV Online](https://embedtvonline.com/)

## ⚖️ Aviso Legal

- Este addon apenas agrega links de conteúdo disponível publicamente
- O usuário é responsável por respeitar os direitos autorais e as leis locais
- Os desenvolvedores não são responsáveis pelo conteúdo reproduzido

## 📝 Changelog

### v1.0.0
- Versão inicial
- 101 canais de TV ao vivo
- 6 categorias
- Interface simples e intuitiva

## 🤝 Suporte

Para problemas ou sugestões, entre em contato através do fórum Kodi Brasil.

## 📄 Licença

GPL-2.0-only

---

**TV DO BILL** - Seu agregador de TV ao vivo para Kodi
